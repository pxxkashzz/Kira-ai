# Kira AI — "Your Voice. Your World."

A native Android voice assistant (Kotlin + Jetpack Compose) with a Liquid Glass UI,
Tamil/Tanglish/English voice commands, and real Android system actions. This is a
real Android Studio project — every file under `app/src/main/java` is working
Kotlin, not pseudocode or an HTML mockup.

## 1. Project structure

```
app/src/main/java/com/kiraai/app/
├── MainActivity.kt              Navigation host, permission requests, onboarding gate
├── KiraApplication.kt
├── ui/
│   ├── theme/                   Color.kt, Theme.kt — Liquid Glass palette + Material3 theme
│   ├── components/              GlassCard.kt, GlassOrb.kt — reusable glass surfaces + animated orb
│   └── screens/                 HomeScreen, HistoryScreen, SettingsScreen, OnboardingScreen
├── voice/
│   ├── SpeechRecognitionManager.kt   Wraps android.speech.SpeechRecognizer (ta-IN / en-IN)
│   └── TextToSpeechManager.kt        Wraps android.speech.tts.TextToSpeech
├── command/
│   ├── CommandIntent.kt         Intent types, KiraState, ActionResult
│   └── CommandParser.kt         Rule-based NLU — maps varied Tamil/Tanglish/English phrasings to intents
├── actions/
│   ├── ActionExecutor.kt        Dispatches intents to real Android APIs
│   ├── AppLauncher.kt           Opens installed apps via Intents
│   ├── PhoneActionHandler.kt    Flashlight, volume, alarm, settings shortcuts
│   └── ContactResolver.kt       Contact lookup for "Call Amma"
├── service/
│   └── KiraAccessibilityService.kt   Optional, off by default — only for Back/Home/Screenshot
├── data/
│   ├── HistoryRepository.kt     Local-only command history (SharedPreferences + JSON)
│   └── SettingsRepository.kt    All Settings-screen options
└── viewmodel/
    └── KiraViewModel.kt         Wires voice → parser → executor → TTS → history together
```

## 2. How to build

**Recommended: Android Studio (Koala/2024.1 or newer)**
1. `File > Open` and select the `KiraAI/` folder.
2. Let Android Studio sync Gradle (it will generate the `gradlew` wrapper script
   automatically the first time — this project ships `gradle-wrapper.properties`
   pointing at Gradle 8.7 but not the wrapper jar itself, since it's a binary file).
3. Run on a device or emulator with **Run ▶**.

**Command line** (after Android Studio has generated `gradlew` once, or you supply
your own Gradle 8.7+ install):
```bash
./gradlew assembleDebug      # debug APK → app/build/outputs/apk/debug/app-debug.apk
./gradlew assembleRelease    # release APK (unsigned — see below)
```

**Requirements:** JDK 17, Android SDK Platform 34, minSdk 26 (Android 8.0+).

## 3. Generating a signed release APK

```bash
./gradlew assembleRelease
```
This produces an **unsigned** release APK. To install it on a device you must sign it:
```bash
keytool -genkey -v -keystore kira.keystore -alias kira -keyalg RSA -keysize 2048 -validity 10000
apksigner sign --ks kira.keystore app/build/outputs/apk/release/app-release-unsigned.apk
```
(Or configure a `signingConfig` in `app/build.gradle.kts` and let Android Studio's
**Build > Generate Signed App Bundle / APK** wizard do this for you.)

## 4. Debugging

- **Logcat filter:** `tag:KiraAI` isn't wired up yet — filter by package `com.kiraai.app`
  in Android Studio's Logcat pane.
- **Speech recognition returns nothing:** most emulators have no working
  `SpeechRecognizer` service. Test voice features on a **physical device** with
  Google app / Google Speech Services installed.
- **Tamil TTS sounds wrong or falls back to English:** the device needs a Tamil
  voice pack installed (Settings > System > Languages > Text-to-speech > Install
  voice data). `TextToSpeechManager.availableForLanguage("ta-IN")` tells you if
  one is present before you rely on it.
- **"Go back" / screenshot commands say permission is needed:** these route
  through `KiraAccessibilityService`, which is off by default. Enable it from
  Kira's own Settings screen (Permissions > Accessibility) or
  Settings > Accessibility > Kira AI on the device.

## 5. What is and isn't implemented

**Fully working, real Android code:**
Liquid Glass UI (Compose Canvas + gradients, no fake screenshots), speech-to-text,
text-to-speech, the rule-based Tamil/Tanglish/English command parser (including
"Send message to X saying Y"), app launching, web search, flashlight, volume,
alarms, opening system settings screens, phone dialing with a confirmation card
(with an opt-in trusted-contacts skip list, managed from Settings), a "Type
Instead" fallback when speech recognition fails, local on-device history, and
settings persistence.

**AI-backed general questions ("What is HTML?")**
`ai/GeneralAssistantService.kt` calls the Anthropic API for anything the parser
classifies as `GENERAL_ASSISTANT_RESPONSE`. The key is **never hard-coded**:
1. Copy `local.properties.example` to `local.properties` (gitignored).
2. Set `AI_API_KEY=sk-ant-...` in it.
3. Gradle reads it into `BuildConfig.AI_API_KEY` at build time.

Without a key, Kira still works for every action command — it just tells the
user honestly that general Q&A isn't configured, instead of faking an answer.

**Deliberately limited, and Kira tells the user why instead of faking it:**
- **Screenshot / global Back / Home** require the user to explicitly enable
  `KiraAccessibilityService`, since Android does not allow a normal app to do this
  otherwise.
- **Offline recognition** depends entirely on what speech engine/voice packs the
  user's device has installed; Kira requests `EXTRA_PREFER_OFFLINE` but can't
  guarantee it.
- **SEND_MESSAGE** opens the Messages app pre-filled with the text rather than
  silently sending it, so the user always sees and approves what goes out.

## 6. Permissions requested, and why

| Permission | Requested when | Why |
|---|---|---|
| `RECORD_AUDIO` | Onboarding screen 3 | Voice recognition |
| `CALL_PHONE` | First "Call X" command | Placing the call after user confirms |
| `READ_CONTACTS` | First "Call X" command | Looking up the contact's number |
| `POST_NOTIFICATIONS` | Onboarding (Android 13+) | Future status notifications |
| Accessibility Service | Manually, from Settings | Global Back/Home/Screenshot only — explained on-screen, cannot read screen content |

No permission is requested until the matching feature is actually used, per the
project's privacy requirements — Kira never bundles a blanket permission request.

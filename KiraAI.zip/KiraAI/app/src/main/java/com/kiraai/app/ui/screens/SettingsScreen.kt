package com.kiraai.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.material.icons.filled.Close
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kiraai.app.data.KiraLanguage
import com.kiraai.app.ui.components.GlassCard
import com.kiraai.app.ui.theme.*
import com.kiraai.app.viewmodel.KiraViewModel

@Composable
fun SettingsScreen(viewModel: KiraViewModel, onBack: () -> Unit) {
    val context = LocalContext.current
    var language by remember { mutableStateOf(viewModel.settings.language) }
    var speechOutput by remember { mutableStateOf(viewModel.settings.speechOutputEnabled) }
    var confirmBeforeActions by remember { mutableStateOf(viewModel.settings.confirmBeforeActions) }
    var reducedEffects by remember { mutableStateOf(viewModel.settings.reducedEffectsMode) }

    Column(
        Modifier
            .fillMaxSize()
            .background(KiraBackground)
            .padding(bottom = 24.dp)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.ArrowBack, "Back", tint = TextPrimary, modifier = Modifier.clickable(onClick = onBack))
            Spacer(Modifier.width(12.dp))
            Text("Settings", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
        }

        SectionTitle("Voice")
        GlassSection {
            SettingRow("Language") {
                LanguagePicker(language) {
                    language = it
                    viewModel.settings.language = it
                }
            }
            SettingToggle("Speech output", speechOutput) {
                speechOutput = it
                viewModel.settings.speechOutputEnabled = it
            }
        }

        SectionTitle("Appearance")
        GlassSection {
            SettingToggle("Reduced-effects mode (for older phones)", reducedEffects) {
                reducedEffects = it
                viewModel.settings.reducedEffectsMode = it
            }
        }

        SectionTitle("Permissions")
        GlassSection {
            PermissionRow("Microphone") { openAppSettings(context) }
            PermissionRow("Contacts") { openAppSettings(context) }
            PermissionRow("Phone") { openAppSettings(context) }
            PermissionRow("Notifications") { openAppSettings(context) }
            PermissionRow("Accessibility (for Go back / Screenshot)") {
                context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        SectionTitle("Assistant")
        GlassSection {
            SettingToggle("Confirm before actions like calling", confirmBeforeActions) {
                confirmBeforeActions = it
                viewModel.settings.confirmBeforeActions = it
            }
            TrustedContactsEditor(viewModel)
        }

        SectionTitle("About")
        GlassSection {
            Text("Kira AI", color = TextPrimary, fontSize = 15.sp, modifier = Modifier.padding(16.dp))
            Text("Version 1.0.0", color = TextTertiary, fontSize = 13.sp, modifier = Modifier.padding(start = 16.dp, bottom = 8.dp))
            Text(
                "Kira only uses the permissions each feature needs, keeps your command history on this device, and never records your microphone in the background.",
                color = TextSecondary,
                fontSize = 13.sp,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)
            )
        }
    }
}

private fun openAppSettings(context: android.content.Context) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}"))
    context.startActivity(intent)
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text.uppercase(),
        color = TextTertiary,
        fontSize = 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 8.dp)
    )
}

@Composable
private fun GlassSection(content: @Composable ColumnScope.() -> Unit) {
    GlassCard(
        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(content = content)
    }
}

@Composable
private fun SettingRow(label: String, trailing: @Composable () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 14.sp)
        trailing()
    }
}

@Composable
private fun SettingToggle(label: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    SettingRow(label) {
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = KiraCyan, checkedTrackColor = KiraCyan.copy(alpha = 0.4f))
        )
    }
}

@Composable
private fun PermissionRow(label: String, onOpen: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onOpen).padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, color = TextPrimary, fontSize = 14.sp)
        Text("Manage", color = KiraCyan, fontSize = 13.sp)
    }
}

@Composable
private fun TrustedContactsEditor(viewModel: KiraViewModel) {
    var trusted by remember { mutableStateOf(viewModel.settings.trustedContactsSkipConfirm) }
    var newName by remember { mutableStateOf("") }

    Column(Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(
            "Trusted contacts skip the \"Kira wants to call…\" confirmation",
            color = TextTertiary,
            fontSize = 12.sp
        )
        Spacer(Modifier.height(8.dp))
        if (trusted.isNotEmpty()) {
            Column {
                trusted.forEach { name ->
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(name, color = TextPrimary, fontSize = 13.sp)
                        Icon(
                            Icons.Filled.Close, "Remove", tint = TextTertiary,
                            modifier = Modifier.clickable {
                                trusted = trusted - name
                                viewModel.settings.trustedContactsSkipConfirm = trusted
                            }
                        )
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = newName,
                onValueChange = { newName = it },
                placeholder = { Text("Add contact name", color = TextTertiary, fontSize = 13.sp) },
                singleLine = true,
                textStyle = androidx.compose.ui.text.TextStyle(color = TextPrimary, fontSize = 13.sp),
                colors = TextFieldDefaults.colors(
                    focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                    focusedIndicatorColor = KiraCyan,
                    unfocusedIndicatorColor = TextTertiary
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(8.dp))
            Text(
                "Add",
                color = KiraCyan,
                fontSize = 13.sp,
                modifier = Modifier.clickable {
                    if (newName.isNotBlank()) {
                        trusted = trusted + newName.trim()
                        viewModel.settings.trustedContactsSkipConfirm = trusted
                        newName = ""
                    }
                }
            )
        }
    }
}

@Composable
private fun LanguagePicker(current: KiraLanguage, onSelect: (KiraLanguage) -> Unit) {
    Row {
        KiraLanguage.entries.forEach { lang ->
            Text(
                lang.label,
                color = if (lang == current) KiraCyan else TextTertiary,
                fontSize = 13.sp,
                modifier = Modifier
                    .clickable { onSelect(lang) }
                    .padding(horizontal = 8.dp)
            )
        }
    }
}

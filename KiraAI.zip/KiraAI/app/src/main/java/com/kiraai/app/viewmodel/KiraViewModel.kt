package com.kiraai.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kiraai.app.actions.ActionExecutor
import com.kiraai.app.actions.ExecutionOutcome
import com.kiraai.app.actions.ResolvedContact
import com.kiraai.app.command.CommandParser
import com.kiraai.app.command.KiraState
import com.kiraai.app.data.HistoryItem
import com.kiraai.app.data.HistoryRepository
import com.kiraai.app.data.SettingsRepository
import com.kiraai.app.voice.SpeechRecognitionManager
import com.kiraai.app.voice.TextToSpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ConversationMessage(
    val id: Long = System.currentTimeMillis(),
    val fromUser: Boolean,
    val text: String,
    val timestampMillis: Long = System.currentTimeMillis()
)

data class KiraUiState(
    val kiraState: KiraState = KiraState.IDLE,
    val amplitude: Float = 0f,
    val partialText: String = "",
    val messages: List<ConversationMessage> = emptyList(),
    val pendingCallConfirmation: ResolvedContact? = null,
    val errorMessage: String? = null
)

class KiraViewModel(application: Application) : AndroidViewModel(application) {

    private val speech = SpeechRecognitionManager(application)
    private val tts = TextToSpeechManager(application)
    private val executor = ActionExecutor(application)
    val history = HistoryRepository(application)
    val settings = SettingsRepository(application)

    private val _uiState = MutableStateFlow(KiraUiState())
    val uiState: StateFlow<KiraUiState> = _uiState

    init {
        tts.setLanguage(settings.language.speechTag)
        tts.setRate(settings.speechRate)
    }

    fun onMicTapped() {
        val state = _uiState.value.kiraState
        if (state == KiraState.LISTENING) {
            speech.stopListening()
            setState(KiraState.IDLE)
            return
        }
        if (state != KiraState.IDLE) return // busy processing/speaking

        setState(KiraState.LISTENING)
        speech.startListening(
            languageTag = settings.language.speechTag,
            onPartialResult = { partial -> _uiState.update { it.copy(partialText = partial) } },
            onRmsChanged = { level -> _uiState.update { it.copy(amplitude = level) } },
            onFinalResult = { finalText -> runTextCommand(finalText) },
            onError = { message ->
                setState(KiraState.IDLE)
                _uiState.update { it.copy(errorMessage = message, partialText = "") }
            }
        )
    }

    /** Runs a command as if the user had spoken [text]. Used for both voice results and quick-action taps. */
    fun runTextCommand(text: String) {
        if (_uiState.value.kiraState == KiraState.PROCESSING || _uiState.value.kiraState == KiraState.SPEAKING) return
        _uiState.update { it.copy(partialText = "") }
        if (text.isBlank()) {
            setState(KiraState.IDLE)
            return
        }
        addMessage(fromUser = true, text = text)
        setState(KiraState.PROCESSING)

        viewModelScope.launch {
            val intent = CommandParser.parse(text)
            when (val outcome = executor.execute(intent)) {
                is ExecutionOutcome.Completed -> finishTurn(text, outcome.result.spokenResponse, outcome.result.success)
                is ExecutionOutcome.NeedsCallConfirmation -> {
                    val isTrusted = settings.trustedContactsSkipConfirm
                        .any { it.equals(outcome.contact.name, ignoreCase = true) }
                    val skipConfirmation = isTrusted || !settings.confirmBeforeActions
                    if (skipConfirmation) {
                        val result = executor.confirmCall(outcome.contact)
                        finishTurn(text, result.spokenResponse, result.success)
                    } else {
                        setState(KiraState.IDLE)
                        _uiState.update { it.copy(pendingCallConfirmation = outcome.contact) }
                    }
                }
            }
        }
    }

    fun confirmPendingCall() {
        val contact = _uiState.value.pendingCallConfirmation ?: return
        _uiState.update { it.copy(pendingCallConfirmation = null) }
        val result = executor.confirmCall(contact)
        finishTurn("Call ${contact.name}", result.spokenResponse, result.success)
    }

    fun cancelPendingCall() {
        _uiState.update { it.copy(pendingCallConfirmation = null) }
    }

    private fun finishTurn(command: String, response: String, success: Boolean) {
        addMessage(fromUser = false, text = response)
        history.add(command, response, success)

        if (settings.speechOutputEnabled) {
            setState(KiraState.SPEAKING)
            tts.speak(
                text = response,
                onDone = { setState(KiraState.IDLE) }
            )
        } else {
            setState(KiraState.IDLE)
        }
    }

    private fun addMessage(fromUser: Boolean, text: String) {
        _uiState.update { it.copy(messages = it.messages + ConversationMessage(fromUser = fromUser, text = text)) }
    }

    private fun setState(state: KiraState) {
        _uiState.update { it.copy(kiraState = state) }
    }

    fun clearError() = _uiState.update { it.copy(errorMessage = null) }

    fun refreshHistory(): List<HistoryItem> = history.getAll()

    override fun onCleared() {
        super.onCleared()
        speech.stopListening()
        tts.shutdown()
    }
}

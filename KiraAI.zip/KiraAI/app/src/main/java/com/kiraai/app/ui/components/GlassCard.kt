package com.kiraai.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.dp
import com.kiraai.app.ui.theme.GlassBorder
import com.kiraai.app.ui.theme.GlassHighlight
import com.kiraai.app.ui.theme.GlassSurface

/**
 * The core "Liquid Glass" surface used across Kira: a translucent panel with a
 * soft diagonal highlight (fake refraction) and a thin light border.
 *
 * True background blur-of-content-behind-it (like iOS glass) requires
 * RenderEffect (Android 12+, API 31) applied to a background layer; on
 * unsupported devices we fall back to the same translucent gradient without
 * the blur, which still reads as "glass" and costs far less GPU time.
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(24.dp),
    borderAlpha: Float = 1f,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        GlassSurface,
                        GlassSurface.copy(alpha = GlassSurface.alpha * 0.6f)
                    )
                ),
                shape = shape
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        GlassHighlight.copy(alpha = GlassHighlight.alpha * borderAlpha),
                        GlassBorder.copy(alpha = GlassBorder.alpha * borderAlpha),
                        Color.Transparent
                    )
                ),
                shape = shape
            )
    ) {
        content()
    }
}

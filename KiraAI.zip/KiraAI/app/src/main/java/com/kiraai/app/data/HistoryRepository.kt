package com.kiraai.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Stores command history locally on-device only (SharedPreferences, JSON-encoded).
 * Nothing here is ever sent over the network — matches the privacy requirement
 * that history is not uploaded unnecessarily.
 */
class HistoryRepository(context: Context) {

    private val prefs = context.getSharedPreferences("kira_history", Context.MODE_PRIVATE)
    private val key = "items"

    fun getAll(): List<HistoryItem> {
        val arr = JSONArray(prefs.getString(key, "[]"))
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            HistoryItem(
                id = o.getLong("id"),
                command = o.getString("command"),
                response = o.getString("response"),
                timestampMillis = o.getLong("ts"),
                succeeded = o.getBoolean("ok")
            )
        }.sortedByDescending { it.timestampMillis }
    }

    fun add(command: String, response: String, succeeded: Boolean) {
        val items = getAll().toMutableList()
        items.add(0, HistoryItem(System.currentTimeMillis(), command, response, System.currentTimeMillis(), succeeded))
        save(items.take(500)) // keep the store bounded
    }

    fun deleteItem(id: Long) {
        save(getAll().filterNot { it.id == id })
    }

    fun clear() = save(emptyList())

    private fun save(items: List<HistoryItem>) {
        val arr = JSONArray()
        items.forEach { item ->
            arr.put(JSONObject().apply {
                put("id", item.id)
                put("command", item.command)
                put("response", item.response)
                put("ts", item.timestampMillis)
                put("ok", item.succeeded)
            })
        }
        prefs.edit().putString(key, arr.toString()).apply()
    }
}

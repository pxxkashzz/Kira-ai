package com.kiraai.app.ai

import com.kiraai.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class AssistantAnswer {
    data class Success(val text: String) : AssistantAnswer()
    data class NotConfigured(val message: String) : AssistantAnswer()
    data class Failure(val message: String) : AssistantAnswer()
}

/**
 * Handles GENERAL_ASSISTANT_RESPONSE ("What is HTML?") by calling the Anthropic API.
 *
 * The key is read from BuildConfig.AI_API_KEY, which Gradle populates from
 * local.properties at build time (see app/build.gradle.kts) — it is never
 * committed to source or hard-coded here. If no key is configured, Kira tells
 * the user honestly instead of pretending to answer (see [AssistantAnswer.NotConfigured]),
 * matching the "offline-first / no hard-coded secrets" requirement.
 */
class GeneralAssistantService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun ask(question: String): AssistantAnswer = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.AI_API_KEY
        if (apiKey.isBlank()) {
            return@withContext AssistantAnswer.NotConfigured(
                "Kira: I can chat about that, but general answers need an AI key configured " +
                    "by the developer. Action commands like opening apps still work fully offline."
            )
        }

        val body = JSONObject().apply {
            put("model", "claude-3-5-haiku-latest")
            put("max_tokens", 300)
            put(
                "system",
                "You are Kira, a concise voice assistant. The user is speaking to you and your " +
                    "reply will be read aloud by text-to-speech, so answer in 1-3 short sentences " +
                    "with no markdown, bullet points, or headers."
            )
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", question)
                })
            })
        }

        val request = Request.Builder()
            .url("https://api.anthropic.com/v1/messages")
            .addHeader("x-api-key", apiKey)
            .addHeader("anthropic-version", "2023-06-01")
            .addHeader("content-type", "application/json")
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()

        try {
            client.newCall(request).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext AssistantAnswer.Failure(
                        "Kira couldn't reach the AI service right now."
                    )
                }
                val text = JSONObject(raw)
                    .optJSONArray("content")
                    ?.optJSONObject(0)
                    ?.optString("text")
                    ?.trim()
                if (text.isNullOrBlank()) {
                    AssistantAnswer.Failure("Kira got an empty response from the AI service.")
                } else {
                    AssistantAnswer.Success(text)
                }
            }
        } catch (e: IOException) {
            AssistantAnswer.Failure("Kira: No internet connection for that question.")
        } catch (e: Exception) {
            AssistantAnswer.Failure("Kira couldn't process that question.")
        }
    }
}

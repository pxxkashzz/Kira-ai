package com.kiraai.app.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.content.ContextCompat
import android.Manifest
import android.content.pm.PackageManager
import com.kiraai.app.ai.AssistantAnswer
import com.kiraai.app.ai.GeneralAssistantService
import com.kiraai.app.command.ActionResult
import com.kiraai.app.command.CommandIntent
import com.kiraai.app.command.IntentType
import com.kiraai.app.service.KiraAccessibilityService

sealed class ExecutionOutcome {
    data class Completed(val result: ActionResult) : ExecutionOutcome()
    data class NeedsCallConfirmation(val contact: ResolvedContact) : ExecutionOutcome()
}

/**
 * Runs a parsed [CommandIntent] against real Android APIs and reports back what
 * actually happened. Never returns success unless the underlying call succeeded.
 */
class ActionExecutor(private val context: Context) {

    private val appLauncher = AppLauncher(context)
    private val phoneActions = PhoneActionHandler(context)
    private val contactResolver = ContactResolver(context)
    private val assistant = GeneralAssistantService()

    suspend fun execute(intent: CommandIntent): ExecutionOutcome {
        val result = when (intent.type) {
            IntentType.OPEN_APP -> openApp(intent)
            IntentType.WEB_SEARCH -> webSearch(intent)
            IntentType.CALL_CONTACT -> return callContact(intent)
            IntentType.SET_ALARM -> setAlarm(intent)
            IntentType.OPEN_SETTINGS -> openSettings(intent)
            IntentType.VOLUME_CONTROL -> volumeControl(intent)
            IntentType.FLASHLIGHT_CONTROL -> flashlight(intent)
            IntentType.SCREENSHOT -> screenshot()
            IntentType.NAVIGATION -> navigation(intent)
            IntentType.SEND_MESSAGE -> sendMessage(intent)
            IntentType.GENERAL_ASSISTANT_RESPONSE -> generalAssistant(intent)
            IntentType.TEXT_INPUT, IntentType.SYSTEM_ACTION ->
                ActionResult(false, "Kira: I don't have a handler for that yet.")
            IntentType.UNKNOWN ->
                ActionResult(false, "Kira couldn't understand that command.")
        }
        return ExecutionOutcome.Completed(result)
    }

    /** Called after the user taps [Call] on the confirmation card. */
    fun confirmCall(contact: ResolvedContact): ActionResult {
        if (!hasPermission(Manifest.permission.CALL_PHONE)) {
            return ActionResult(false, "Kira needs Phone permission to place calls.")
        }
        val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:${contact.phoneNumber}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            context.startActivity(intent)
            ActionResult(true, "Kira: Calling ${contact.name}.")
        } catch (e: SecurityException) {
            ActionResult(false, "Kira needs Phone permission to place calls.")
        }
    }

    // ---------------------------------------------------------------------

    private fun openApp(intent: CommandIntent): ActionResult {
        val app = intent.slots["app"] ?: return ActionResult(false, "Which app should Kira open?")
        val launched = appLauncher.open(app)
        return if (launched) {
            ActionResult(true, "Kira: ${app.replaceFirstChar { it.uppercase() }} open panren.")
        } else {
            ActionResult(false, "Kira: That app isn't installed on your phone.")
        }
    }

    private fun webSearch(intent: CommandIntent): ActionResult {
        val query = intent.slots["query"] ?: return ActionResult(false, "What should Kira search for?")
        val engine = intent.slots["engine"] ?: "google"
        val encoded = Uri.encode(query)
        val url = if (engine == "youtube") {
            "https://www.youtube.com/results?search_query=$encoded"
        } else {
            "https://www.google.com/search?q=$encoded"
        }
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return if (webIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(webIntent)
            ActionResult(true, "Kira: Searching for \"$query\".")
        } else {
            ActionResult(false, "Kira couldn't find a browser to search with.")
        }
    }

    private fun callContact(intent: CommandIntent): ExecutionOutcome {
        val name = intent.slots["contact"] ?: return ExecutionOutcome.Completed(
            ActionResult(false, "Who should Kira call?")
        )
        if (!hasPermission(Manifest.permission.READ_CONTACTS)) {
            return ExecutionOutcome.Completed(ActionResult(false, "Kira needs Contacts permission to find $name."))
        }
        val contact = contactResolver.findByName(name)
            ?: return ExecutionOutcome.Completed(ActionResult(false, "Kira: Couldn't find a contact named $name."))
        return ExecutionOutcome.NeedsCallConfirmation(contact)
    }

    private fun sendMessage(intent: CommandIntent): ActionResult {
        // Kira drafts the SMS via the system Messages app rather than sending
        // silently, so the user always sees and confirms what goes out.
        val body = intent.slots["message"].orEmpty()
        val contactName = intent.slots["contact"]

        var number: String? = null
        if (!contactName.isNullOrBlank() && hasPermission(Manifest.permission.READ_CONTACTS)) {
            number = contactResolver.findByName(contactName)?.phoneNumber
        }

        val uri = if (number != null) Uri.parse("smsto:$number") else Uri.parse("smsto:")
        val smsIntent = Intent(Intent.ACTION_SENDTO, uri).apply {
            putExtra("sms_body", body)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return if (smsIntent.resolveActivity(context.packageManager) != null) {
            context.startActivity(smsIntent)
            val who = if (number != null) " to $contactName" else ""
            ActionResult(true, "Kira: Opening Messages$who so you can send that.")
        } else {
            ActionResult(false, "Kira couldn't find a messaging app.")
        }
    }

    private fun setAlarm(intent: CommandIntent): ActionResult {
        val time = intent.slots["time"] ?: return ActionResult(false, "What time should Kira set the alarm for?")
        return if (phoneActions.setAlarm(time)) {
            ActionResult(true, "Kira: Alarm set for $time.")
        } else {
            ActionResult(false, "Kira: That doesn't look like a valid alarm time.")
        }
    }

    private fun openSettings(intent: CommandIntent): ActionResult {
        val target = intent.slots["target"] ?: "general"
        return if (phoneActions.openSystemSettings(target)) {
            ActionResult(true, "Kira: Opening settings.")
        } else {
            ActionResult(false, "Kira couldn't open that settings screen.")
        }
    }

    private fun volumeControl(intent: CommandIntent): ActionResult {
        val direction = intent.slots["direction"] ?: "up"
        phoneActions.adjustVolume(direction)
        return ActionResult(true, "Kira: Volume ${direction}.")
    }

    private fun flashlight(intent: CommandIntent): ActionResult {
        val state = intent.slots["state"] ?: "on"
        val ok = phoneActions.setFlashlight(state == "on")
        return if (ok) {
            ActionResult(true, "Kira: Flashlight $state.")
        } else {
            ActionResult(false, "Kira: This device doesn't have a flashlight Kira can control.")
        }
    }

    private fun screenshot(): ActionResult {
        if (!KiraAccessibilityService.isEnabled()) {
            return ActionResult(
                false,
                "Kira needs the Accessibility permission enabled to take a screenshot. You can turn it on from Settings."
            )
        }
        return if (KiraAccessibilityService.takeScreenshot()) {
            ActionResult(true, "Kira: Screenshot taken.")
        } else {
            ActionResult(false, "Kira: Screenshot isn't supported on this Android version.")
        }
    }

    private fun navigation(intent: CommandIntent): ActionResult {
        val direction = intent.slots["direction"] ?: "back"
        if (!KiraAccessibilityService.isEnabled()) {
            return ActionResult(
                false,
                "Kira needs the Accessibility permission enabled for navigation commands. You can turn it on from Settings."
            )
        }
        val ok = if (direction == "home") KiraAccessibilityService.goHome() else KiraAccessibilityService.goBack()
        return if (ok) ActionResult(true, "Kira: Going $direction.") else ActionResult(false, "Kira couldn't do that.")
    }

    private suspend fun generalAssistant(intent: CommandIntent): ActionResult {
        val question = intent.slots["query"] ?: intent.rawText
        return when (val answer = assistant.ask(question)) {
            is AssistantAnswer.Success -> ActionResult(true, answer.text)
            is AssistantAnswer.NotConfigured -> ActionResult(false, answer.message)
            is AssistantAnswer.Failure -> ActionResult(false, answer.message)
        }
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}

package com.kiraai.app.command

/** Visual/voice state of the assistant, drives the orb animation and status text. */
enum class KiraState { IDLE, LISTENING, PROCESSING, SPEAKING }

/** The categories the spec calls for. Keep this the single source of truth for intents. */
enum class IntentType {
    OPEN_APP,
    WEB_SEARCH,
    CALL_CONTACT,
    SEND_MESSAGE,
    SET_ALARM,
    OPEN_SETTINGS,
    VOLUME_CONTROL,
    FLASHLIGHT_CONTROL,
    SCREENSHOT,
    NAVIGATION,
    TEXT_INPUT,
    SYSTEM_ACTION,
    GENERAL_ASSISTANT_RESPONSE,
    UNKNOWN
}

/**
 * A parsed command ready for [com.kiraai.app.actions.ActionExecutor].
 * `slots` carries whatever free text the intent needs (app name, query, contact name, etc).
 */
data class CommandIntent(
    val type: IntentType,
    val rawText: String,
    val slots: Map<String, String> = emptyMap()
)

/** Result Kira reports back to the UI/history after trying to run a [CommandIntent]. */
data class ActionResult(
    val success: Boolean,
    val spokenResponse: String,
    val displayResponse: String = spokenResponse
)

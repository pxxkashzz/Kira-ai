package com.kiraai.app.actions

import android.content.Context
import android.provider.ContactsContract

data class ResolvedContact(val name: String, val phoneNumber: String)

class ContactResolver(private val context: Context) {

    /** Best-effort fuzzy lookup by display name. Requires READ_CONTACTS to already be granted. */
    fun findByName(name: String): ResolvedContact? {
        val resolver = context.contentResolver
        val projection = arrayOf(
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
            ContactsContract.CommonDataKinds.Phone.NUMBER
        )
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%$name%")

        resolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            projection, selection, args, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val nameIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val numberIdx = cursor.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return ResolvedContact(cursor.getString(nameIdx), cursor.getString(numberIdx))
            }
        }
        return null
    }
}

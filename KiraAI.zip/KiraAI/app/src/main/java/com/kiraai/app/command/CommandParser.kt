package com.kiraai.app.command

/**
 * Turns raw recognized speech into a [CommandIntent].
 *
 * This is a rule-based (offline, no server needed) natural-language layer, not a
 * literal string match — it strips Tanglish "helper" words (pannu, pannunga,
 * panren, ah, please...) and matches the remaining phrase against per-intent
 * patterns, so "Open YouTube", "YouTube open pannu" and "YouTube ah open
 * pannunga" all resolve to the same OPEN_APP intent. Add new phrasings by
 * extending the *Patterns lists below — nothing else needs to change.
 */
object CommandParser {

    // Tanglish filler/verb words that don't carry meaning once the intent is known.
    private val fillerWords = listOf(
        "pannu", "pannunga", "panren", "podu", "podunga", "please",
        "kindly", "ah", "the", "my", "ku", "na", "naa"
    )

    private val appAliases: Map<String, List<String>> = mapOf(
        "youtube" to listOf("youtube", "you tube"),
        "chrome" to listOf("chrome", "browser"),
        "camera" to listOf("camera", "cam"),
        "gallery" to listOf("gallery", "photos"),
        "phone" to listOf("phone", "dialer", "call app"),
        "messages" to listOf("messages", "message", "sms"),
        "settings" to listOf("settings", "setting"),
        "maps" to listOf("maps", "map", "google maps"),
        "whatsapp" to listOf("whatsapp", "whats app")
    )

    fun parse(rawText: String): CommandIntent {
        val text = normalize(rawText)
        if (text.isBlank()) return CommandIntent(IntentType.UNKNOWN, rawText)

        parseFlashlight(text, rawText)?.let { return it }
        parseVolume(text, rawText)?.let { return it }
        parseScreenshot(text, rawText)?.let { return it }
        parseNavigation(text, rawText)?.let { return it }
        parseAlarm(text, rawText)?.let { return it }
        parseSendMessage(text, rawText)?.let { return it }
        parseCall(text, rawText)?.let { return it }
        parseWebSearch(text, rawText)?.let { return it }
        parseOpenSettings(text, rawText)?.let { return it }
        parseOpenApp(text, rawText)?.let { return it }

        return if (looksLikeQuestion(text)) {
            CommandIntent(IntentType.GENERAL_ASSISTANT_RESPONSE, rawText, mapOf("query" to rawText))
        } else {
            CommandIntent(IntentType.UNKNOWN, rawText)
        }
    }

    private fun normalize(text: String): String {
        var t = text.trim().lowercase()
        fillerWords.forEach { w -> t = t.replace(Regex("\\b${Regex.escape(w)}\\b"), " ") }
        return t.replace(Regex("\\s+"), " ").trim()
    }

    private fun looksLikeQuestion(text: String): Boolean {
        val starters = listOf("what", "why", "how", "who", "when", "where", "enna", "yaaru", "eppo", "epdi")
        return starters.any { text.startsWith(it) } || text.endsWith("?")
    }

    // ---- OPEN_APP ------------------------------------------------------

    private fun parseOpenApp(text: String, raw: String): CommandIntent? {
        for ((canonical, aliases) in appAliases) {
            for (alias in aliases) {
                if (Regex("\\b(open|start|launch)?\\s*${Regex.escape(alias)}\\s*(open|start|launch)?\\b").containsMatchIn(text)) {
                    return CommandIntent(IntentType.OPEN_APP, raw, mapOf("app" to canonical))
                }
            }
        }
        return null
    }

    // ---- WEB_SEARCH ------------------------------------------------------

    private val searchPatterns = listOf(
        // "google la naruto search pannu" / "google il naruto search"
        Regex("(google|youtube|chrome)\\s*(la|il|le)?\\s+(?<q>.+?)\\s+search"),
        // "search naruto on google" / "search for naruto"
        Regex("search\\s+(for\\s+)?(?<q>.+?)(\\s+(on|in)\\s+(?<engine>google|youtube))?$"),
        // "google search naruto"
        Regex("(?<engine>google|youtube)\\s+search\\s+(?<q>.+)")
    )

    private fun parseWebSearch(text: String, raw: String): CommandIntent? {
        for (pattern in searchPatterns) {
            val match = pattern.find(text) ?: continue
            val query = match.groups["q"]?.value?.trim() ?: continue
            if (query.isBlank()) continue
            val engine = match.groups["engine"]?.value ?: if (text.contains("youtube")) "youtube" else "google"
            return CommandIntent(IntentType.WEB_SEARCH, raw, mapOf("query" to query, "engine" to engine))
        }
        return null
    }

    // ---- SEND_MESSAGE ------------------------------------------------------

    private val sendMessagePatterns = listOf(
        Regex("send\\s+(a\\s+)?(message|text|sms)\\s+to\\s+(?<contact>.+?)\\s+(saying|that says?|with)\\s+(?<msg>.+)"),
        Regex("(message|text)\\s+(?<contact>.+?)\\s+(saying|that says?)\\s+(?<msg>.+)"),
        Regex("send\\s+(a\\s+)?(message|text|sms)\\s+to\\s+(?<contact>.+)")
    )

    private fun parseSendMessage(text: String, raw: String): CommandIntent? {
        if (!(text.contains("message") || text.contains(" sms") || text.startsWith("sms") || text.contains(" text "))) return null
        // "message" alone is too ambiguous with the Messages app alias — require "send"/"to"/"saying" context.
        if (!(text.contains("send") || text.contains("saying") || text.contains(" to "))) return null
        for (pattern in sendMessagePatterns) {
            val match = pattern.find(text) ?: continue
            val contact = match.groups["contact"]?.value?.trim()
            val body = match.groups["msg"]?.value?.trim()
            if (contact.isNullOrBlank()) continue
            val slots = mutableMapOf("contact" to contact)
            if (!body.isNullOrBlank()) slots["message"] = body
            return CommandIntent(IntentType.SEND_MESSAGE, raw, slots)
        }
        return null
    }

    // ---- CALL_CONTACT ------------------------------------------------------

    private val callPatterns = listOf(
        Regex("call\\s+(?<name>.+)"),
        Regex("(?<name>.+?)\\s*(ku|kku)?\\s*call")
    )

    private fun parseCall(text: String, raw: String): CommandIntent? {
        if (!text.contains("call")) return null
        for (pattern in callPatterns) {
            val match = pattern.find(text) ?: continue
            val name = match.groups["name"]?.value?.trim()?.trim('.', ',')
            if (!name.isNullOrBlank()) {
                return CommandIntent(IntentType.CALL_CONTACT, raw, mapOf("contact" to name))
            }
        }
        return null
    }

    // ---- SET_ALARM ------------------------------------------------------

    private val alarmPattern =
        Regex("(set\\s+)?alarm\\s+(for\\s+)?(?<time>\\d{1,2}(:\\d{2})?\\s*(am|pm)?)")

    private fun parseAlarm(text: String, raw: String): CommandIntent? {
        if (!text.contains("alarm")) return null
        val match = alarmPattern.find(text) ?: return null
        val time = match.groups["time"]?.value?.trim() ?: return null
        return CommandIntent(IntentType.SET_ALARM, raw, mapOf("time" to time))
    }

    // ---- VOLUME_CONTROL ------------------------------------------------------

    private fun parseVolume(text: String, raw: String): CommandIntent? {
        if (!text.contains("volume")) return null
        val direction = when {
            Regex("up|increase|max|raise").containsMatchIn(text) -> "up"
            Regex("down|decrease|reduce|low").containsMatchIn(text) -> "down"
            Regex("mute|silent").containsMatchIn(text) -> "mute"
            else -> "up"
        }
        return CommandIntent(IntentType.VOLUME_CONTROL, raw, mapOf("direction" to direction))
    }

    // ---- FLASHLIGHT_CONTROL ------------------------------------------------------

    private fun parseFlashlight(text: String, raw: String): CommandIntent? {
        if (!(text.contains("flashlight") || text.contains("torch"))) return null
        val state = if (Regex("\\boff\\b").containsMatchIn(text)) "off" else "on"
        return CommandIntent(IntentType.FLASHLIGHT_CONTROL, raw, mapOf("state" to state))
    }

    // ---- SCREENSHOT ------------------------------------------------------

    private fun parseScreenshot(text: String, raw: String): CommandIntent? {
        if (!text.contains("screenshot")) return null
        return CommandIntent(IntentType.SCREENSHOT, raw)
    }

    // ---- NAVIGATION (go back / go home) ------------------------------------------------------

    private fun parseNavigation(text: String, raw: String): CommandIntent? {
        val direction = when {
            Regex("go\\s*back|back\\s*po").containsMatchIn(text) -> "back"
            Regex("go\\s*home|home\\s*po").containsMatchIn(text) -> "home"
            else -> return null
        }
        return CommandIntent(IntentType.NAVIGATION, raw, mapOf("direction" to direction))
    }

    // ---- OPEN_SETTINGS ------------------------------------------------------

    private fun parseOpenSettings(text: String, raw: String): CommandIntent? {
        if (!text.contains("settings")) return null
        val target = when {
            text.contains("wifi") || text.contains("wi-fi") || text.contains("wi fi") -> "wifi"
            text.contains("bluetooth") -> "bluetooth"
            text.contains("notification") -> "notifications"
            else -> "general"
        }
        return CommandIntent(IntentType.OPEN_SETTINGS, raw, mapOf("target" to target))
    }
}

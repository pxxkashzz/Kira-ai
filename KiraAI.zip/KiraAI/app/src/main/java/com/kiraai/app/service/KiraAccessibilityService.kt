package com.kiraai.app.service

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.view.accessibility.AccessibilityEvent
import java.lang.ref.WeakReference

/**
 * Kira only uses the Accessibility API for [performGlobalAction] — global
 * "Back" / "Home" / "Take screenshot" gestures that no normal Android app is
 * allowed to trigger by itself. The service config disables window-content
 * retrieval (see accessibility_service_config.xml), so Kira cannot read what
 * is on screen. It is off by default; the user must explicitly turn it on
 * from Settings > Accessibility after reading the in-app explanation.
 */
class KiraAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = WeakReference(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally empty — Kira does not inspect screen content or events.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
    }

    companion object {
        private var instance: WeakReference<KiraAccessibilityService>? = null

        fun isEnabled(): Boolean = instance?.get() != null

        fun goBack(): Boolean = instance?.get()?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false

        fun goHome(): Boolean = instance?.get()?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false

        fun takeScreenshot(): Boolean {
            val svc = instance?.get() ?: return false
            return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                svc.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
            } else {
                false
            }
        }
    }
}

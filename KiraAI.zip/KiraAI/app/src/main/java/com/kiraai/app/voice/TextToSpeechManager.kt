package com.kiraai.app.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.UUID

class TextToSpeechManager(context: Context) {

    private var tts: TextToSpeech? = null
    private var ready = false
    private var pendingRate = 1.0f

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            tts?.setSpeechRate(pendingRate)
        }
    }

    fun setLanguage(tag: String) {
        val locale = if (tag.startsWith("ta")) Locale("ta", "IN") else Locale("en", "IN")
        val result = tts?.setLanguage(locale)
        // TTS_MISSING_DATA / LANG_NOT_SUPPORTED means this device has no Tamil TTS voice
        // installed. We don't pretend it worked — callers can check availability().
    }

    fun availableForLanguage(tag: String): Boolean {
        val locale = if (tag.startsWith("ta")) Locale("ta", "IN") else Locale("en", "IN")
        val result = tts?.isLanguageAvailable(locale) ?: TextToSpeech.LANG_NOT_SUPPORTED
        return result >= TextToSpeech.LANG_AVAILABLE
    }

    fun setRate(rate: Float) {
        pendingRate = rate
        tts?.setSpeechRate(rate)
    }

    fun speak(text: String, onStart: () -> Unit = {}, onDone: () -> Unit = {}) {
        if (!ready || text.isBlank()) {
            onDone()
            return
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = onStart()
            override fun onDone(utteranceId: String?) = onDone()
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = onDone()
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UUID.randomUUID().toString())
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.shutdown()
    }
}

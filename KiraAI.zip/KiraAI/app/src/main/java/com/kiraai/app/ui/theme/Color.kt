package com.kiraai.app.ui.theme

import androidx.compose.ui.graphics.Color

// Deep black canvas
val KiraBackground = Color(0xFF05050A)
val KiraBackgroundGlow1 = Color(0xFF12203A)
val KiraBackgroundGlow2 = Color(0xFF1B0F2E)

// Glass surfaces
val GlassSurface = Color(0x1AFFFFFF)      // ~10% white, translucent panel
val GlassSurfaceStrong = Color(0x33FFFFFF)
val GlassBorder = Color(0x40FFFFFF)
val GlassHighlight = Color(0x66FFFFFF)

// Accent — cool cyan/violet, used sparingly (not neon-excessive)
val KiraCyan = Color(0xFF6FE3FF)
val KiraViolet = Color(0xFFB18CFF)
val KiraAmber = Color(0xFFFFC98C) // used only for warnings/errors

val TextPrimary = Color(0xFFF5F7FA)
val TextSecondary = Color(0xB3F5F7FA)
val TextTertiary = Color(0x73F5F7FA)

package com.kiraai.app.data

import android.content.Context

enum class KiraLanguage(val speechTag: String, val label: String) {
    ENGLISH("en-IN", "English"),
    TAMIL("ta-IN", "தமிழ்")
}

/** All user-configurable Settings-screen options, persisted locally. */
class SettingsRepository(context: Context) {

    private val prefs = context.getSharedPreferences("kira_settings", Context.MODE_PRIVATE)

    var language: KiraLanguage
        get() = if (prefs.getString("lang", "en-IN") == "ta-IN") KiraLanguage.TAMIL else KiraLanguage.ENGLISH
        set(value) = prefs.edit().putString("lang", value.speechTag).apply()

    var speechOutputEnabled: Boolean
        get() = prefs.getBoolean("speech_output", true)
        set(value) = prefs.edit().putBoolean("speech_output", value).apply()

    var speechRate: Float
        get() = prefs.getFloat("speech_rate", 1.0f)
        set(value) = prefs.edit().putFloat("speech_rate", value).apply()

    var glassIntensity: Float
        get() = prefs.getFloat("glass_intensity", 1.0f)
        set(value) = prefs.edit().putFloat("glass_intensity", value).apply()

    var reducedEffectsMode: Boolean
        get() = prefs.getBoolean("reduced_effects", false)
        set(value) = prefs.edit().putBoolean("reduced_effects", value).apply()

    var confirmBeforeActions: Boolean
        get() = prefs.getBoolean("confirm_before_actions", true)
        set(value) = prefs.edit().putBoolean("confirm_before_actions", value).apply()

    var trustedContactsSkipConfirm: Set<String>
        get() = prefs.getStringSet("trusted_contacts", emptySet()) ?: emptySet()
        set(value) = prefs.edit().putStringSet("trusted_contacts", value).apply()

    var onboardingComplete: Boolean
        get() = prefs.getBoolean("onboarding_complete", false)
        set(value) = prefs.edit().putBoolean("onboarding_complete", value).apply()
}

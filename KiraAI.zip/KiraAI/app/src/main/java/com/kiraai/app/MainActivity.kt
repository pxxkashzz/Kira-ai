package com.kiraai.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.kiraai.app.data.KiraLanguage
import com.kiraai.app.ui.screens.HistoryScreen
import com.kiraai.app.ui.screens.HomeScreen
import com.kiraai.app.ui.screens.OnboardingScreen
import com.kiraai.app.ui.screens.SettingsScreen
import com.kiraai.app.ui.theme.KiraAITheme
import com.kiraai.app.viewmodel.KiraViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: KiraViewModel by viewModels()

    // Requested opportunistically: RECORD_AUDIO during onboarding, CALL_PHONE /
    // READ_CONTACTS / POST_NOTIFICATIONS the first time a command needs them.
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { }
    private val multiPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            KiraAITheme {
                val navController = rememberNavController()
                val onboardingDone = remember { mutableStateOf(viewModel.settings.onboardingComplete) }

                NavHost(navController, startDestination = if (onboardingDone.value) "home" else "onboarding") {
                    composable("onboarding") {
                        OnboardingScreen(
                            onRequestMicPermission = { requestCorePermissions() },
                            onLanguageSelected = { lang -> viewModel.settings.language = lang },
                            onFinish = {
                                viewModel.settings.onboardingComplete = true
                                onboardingDone.value = true
                                navController.navigate("home") {
                                    popUpTo("onboarding") { inclusive = true }
                                }
                            }
                        )
                    }
                    composable("home") {
                        HomeScreen(
                            viewModel = viewModel,
                            onOpenHistory = { navController.navigate("history") },
                            onOpenSettings = { navController.navigate("settings") },
                            onQuickAction = { key -> handleQuickAction(key) }
                        )
                    }
                    composable("history") {
                        HistoryScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
                    }
                    composable("settings") {
                        SettingsScreen(viewModel = viewModel, onBack = { navController.popBackStack() })
                    }
                }
            }
        }
    }

    private fun handleQuickAction(key: String) {
        // Quick action taps run the exact same parser/executor path a spoken
        // command would — they are just a shortcut for typing/speaking it.
        val text = when (key) {
            "youtube" -> "Open YouTube"
            "camera" -> "Open Camera"
            "chrome" -> "Open Chrome"
            "phone" -> "Open Phone"
            "settings" -> "Open Settings"
            "search" -> "Search Google"
            else -> return
        }
        viewModel.runTextCommand(text)
    }

    private fun requestCorePermissions() {
        val permissions = mutableListOf(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        multiPermissionLauncher.launch(permissions.toTypedArray())
    }
}

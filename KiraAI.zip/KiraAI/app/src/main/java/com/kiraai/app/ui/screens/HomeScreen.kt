package com.kiraai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kiraai.app.command.KiraState
import com.kiraai.app.ui.components.GlassCard
import com.kiraai.app.ui.components.GlassOrb
import com.kiraai.app.ui.theme.*
import com.kiraai.app.viewmodel.ConversationMessage
import com.kiraai.app.viewmodel.KiraViewModel

@Composable
fun HomeScreen(
    viewModel: KiraViewModel,
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    onQuickAction: (String) -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.radialGradient(
                    colors = listOf(KiraBackgroundGlow1.copy(alpha = 0.35f), KiraBackground),
                    radius = 1200f
                )
            )
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            TopBar(onOpenHistory, onOpenSettings)

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (state.messages.isEmpty()) {
                    Spacer(Modifier.height(24.dp))
                    Text("Your intelligent voice assistant", style = KiraTypography.bodyMedium)
                    Spacer(Modifier.weight(1f))
                } else {
                    ConversationList(
                        messages = state.messages,
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    )
                }

                StatusLabel(state.kiraState, state.partialText)

                Spacer(Modifier.height(12.dp))
                GlassOrb(
                    state = state.kiraState,
                    amplitude = state.amplitude,
                    onTap = { viewModel.onMicTapped() },
                    reducedMotion = viewModel.settings.reducedEffectsMode
                )
                Spacer(Modifier.height(28.dp))
            }

            QuickActionsRow(onQuickAction)
            Spacer(Modifier.height(20.dp))
        }

        state.pendingCallConfirmation?.let { contact ->
            CallConfirmationDialog(
                name = contact.name,
                onCancel = { viewModel.cancelPendingCall() },
                onConfirm = { viewModel.confirmPendingCall() }
            )
        }

        state.errorMessage?.let { message ->
            ErrorCard(
                message = message,
                onDismiss = { viewModel.clearError() },
                onTypeInstead = { typed -> viewModel.clearError(); viewModel.runTextCommand(typed) }
            )
        }
    }
}

@Composable
private fun TopBar(onOpenHistory: () -> Unit, onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 16.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("KIRA AI", color = TextPrimary, fontWeight = FontWeight.SemiBold, fontSize = 20.sp, letterSpacing = 2.sp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            IconGlassButton(Icons.Filled.History, "Command history", onOpenHistory)
            IconGlassButton(Icons.Filled.Settings, "Settings", onOpenSettings)
        }
    }
}

@Composable
private fun IconGlassButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
    GlassCard(
        modifier = Modifier
            .size(42.dp)
            .clickable(onClick = onClick),
        shape = CircleShape
    ) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = description, tint = TextPrimary, modifier = Modifier.size(20.dp))
        }
    }
}

@Composable
private fun StatusLabel(state: KiraState, partialText: String) {
    val text = when (state) {
        KiraState.IDLE -> if (partialText.isBlank()) "Tap to speak" else partialText
        KiraState.LISTENING -> if (partialText.isNotBlank()) partialText else "Listening..."
        KiraState.PROCESSING -> "Thinking..."
        KiraState.SPEAKING -> "Kira is speaking..."
    }
    Text(text, color = TextSecondary, fontSize = 15.sp)
}

@Composable
private fun ConversationList(messages: List<ConversationMessage>, modifier: Modifier = Modifier) {
    LazyColumn(
        modifier = modifier.padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        reverseLayout = true
    ) {
        items(messages.reversed()) { msg -> MessageBubble(msg) }
    }
}

@Composable
private fun MessageBubble(message: ConversationMessage) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        GlassCard(
            modifier = Modifier.widthIn(max = 280.dp),
            shape = RoundedCornerShape(18.dp),
            borderAlpha = if (message.fromUser) 1f else 0.6f
        ) {
            Text(
                message.text,
                color = TextPrimary,
                fontSize = 14.sp,
                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
            )
        }
    }
}

@Composable
private fun QuickActionsRow(onQuickAction: (String) -> Unit) {
    val actions = listOf(
        "youtube" to Icons.Filled.PlayArrow,
        "camera" to Icons.Filled.CameraAlt,
        "chrome" to Icons.Filled.Public,
        "phone" to Icons.Filled.Call,
        "search" to Icons.Filled.Search,
        "settings" to Icons.Filled.Settings
    )
    LazyRow(
        contentPadding = PaddingValues(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(actions) { (key, icon) ->
            GlassCard(
                modifier = Modifier
                    .size(56.dp)
                    .clickable { onQuickAction(key) },
                shape = CircleShape
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(icon, contentDescription = key, tint = KiraCyan, modifier = Modifier.size(22.dp))
                }
            }
        }
    }
}

@Composable
private fun BoxScope.CallConfirmationDialog(name: String, onCancel: () -> Unit, onConfirm: () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.55f))
            .align(Alignment.Center),
        contentAlignment = Alignment.Center
    ) {
        GlassCard(modifier = Modifier.padding(32.dp).fillMaxWidth(), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.padding(24.dp)) {
                Text("Kira wants to call $name.", color = TextPrimary, fontWeight = FontWeight.Medium, fontSize = 17.sp)
                Spacer(Modifier.height(20.dp))
                Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                    DialogButton("Cancel", onCancel)
                    Spacer(Modifier.width(12.dp))
                    DialogButton("Call", onConfirm, emphasized = true)
                }
            }
        }
    }
}

@Composable
private fun DialogButton(label: String, onClick: () -> Unit, emphasized: Boolean = false) {
    GlassCard(
        modifier = Modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        borderAlpha = if (emphasized) 1f else 0.4f
    ) {
        Text(
            label,
            color = if (emphasized) KiraCyan else TextSecondary,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
        )
    }
}

@Composable
private fun BoxScope.ErrorCard(message: String, onDismiss: () -> Unit, onTypeInstead: (String) -> Unit) {
    var showTypeField by remember { mutableStateOf(false) }
    var typedText by remember { mutableStateOf("") }

    GlassCard(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(20.dp)
            .fillMaxWidth(),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text("Kira couldn't do that", color = KiraAmber, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text(message, color = TextSecondary, fontSize = 13.sp)

            if (showTypeField) {
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = typedText,
                    onValueChange = { typedText = it },
                    placeholder = { Text("Type your command…", color = TextTertiary, fontSize = 13.sp) },
                    singleLine = true,
                    textStyle = androidx.compose.ui.text.TextStyle(color = TextPrimary, fontSize = 14.sp),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                        unfocusedContainerColor = androidx.compose.ui.graphics.Color.Transparent,
                        focusedIndicatorColor = KiraCyan,
                        unfocusedIndicatorColor = TextTertiary
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                if (showTypeField) {
                    DialogButton("Send") {
                        if (typedText.isNotBlank()) {
                            onTypeInstead(typedText)
                            typedText = ""
                            showTypeField = false
                        }
                    }
                } else {
                    DialogButton("Type Instead") { showTypeField = true }
                    Spacer(Modifier.width(12.dp))
                    DialogButton("Try Again", onDismiss, emphasized = true)
                }
            }
        }
    }
}

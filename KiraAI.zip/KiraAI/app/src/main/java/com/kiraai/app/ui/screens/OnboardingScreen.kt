package com.kiraai.app.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kiraai.app.data.KiraLanguage
import com.kiraai.app.ui.components.GlassCard
import com.kiraai.app.ui.theme.*

private data class OnboardingPage(val title: String, val subtitle: String)

private val pages = listOf(
    OnboardingPage("Kira AI", "Your voice. Your commands."),
    OnboardingPage("Speak Naturally", "Speak naturally in Tamil or English."),
    OnboardingPage("Microphone Access", "Give Kira permission to use your microphone."),
    OnboardingPage("Choose Your Language", "Choose your preferred language."),
    OnboardingPage("You're Ready", "You're ready.")
)

@Composable
fun OnboardingScreen(
    onRequestMicPermission: () -> Unit,
    onLanguageSelected: (KiraLanguage) -> Unit,
    onFinish: () -> Unit
) {
    var pageIndex by remember { mutableIntStateOf(0) }
    var selectedLanguage by remember { mutableStateOf(KiraLanguage.ENGLISH) }

    Box(
        Modifier
            .fillMaxSize()
            .background(KiraBackground),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.fillMaxSize().padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            AnimatedContent(targetState = pageIndex, label = "onboarding") { index ->
                val page = pages[index]
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(page.title, color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Light, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text(page.subtitle, color = TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Center)

                    if (index == 3) {
                        Spacer(Modifier.height(24.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            KiraLanguage.entries.forEach { lang ->
                                LanguageChip(lang, selected = lang == selectedLanguage) {
                                    selectedLanguage = lang
                                    onLanguageSelected(lang)
                                }
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(48.dp))

            GlassCard(
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.clickable {
                    when (pageIndex) {
                        2 -> { onRequestMicPermission(); pageIndex++ }
                        pages.lastIndex -> onFinish()
                        else -> pageIndex++
                    }
                }
            ) {
                Text(
                    if (pageIndex == pages.lastIndex) "Start Kira" else "Next",
                    color = KiraCyan,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier.padding(horizontal = 32.dp, vertical = 14.dp)
                )
            }
        }
    }
}

@Composable
private fun LanguageChip(lang: KiraLanguage, selected: Boolean, onClick: () -> Unit) {
    GlassCard(
        shape = RoundedCornerShape(12.dp),
        borderAlpha = if (selected) 1f else 0.4f,
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            lang.label,
            color = if (selected) KiraCyan else TextSecondary,
            modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
        )
    }
}

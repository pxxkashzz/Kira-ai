package com.kiraai.app.actions

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import android.provider.Settings

/**
 * Opens installed apps using legitimate Android intents. Never fakes success:
 * every branch returns whether it actually found something launchable.
 */
class AppLauncher(private val context: Context) {

    // Known package names for common apps, used only as a hint — we always
    // verify with PackageManager before claiming an app is installed.
    private val knownPackages = mapOf(
        "youtube" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "whatsapp" to "com.whatsapp",
        "maps" to "com.google.android.apps.maps",
        "messages" to "com.google.android.apps.messaging"
    )

    fun isInstalled(packageName: String): Boolean = try {
        context.packageManager.getPackageInfo(packageName, 0)
        true
    } catch (e: Exception) {
        false
    }

    /** Returns true if an app was actually launched. */
    fun open(appKey: String): Boolean {
        val intent: Intent? = when (appKey) {
            "camera" -> Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
            "gallery" -> Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            }
            "phone" -> Intent(Intent.ACTION_DIAL)
            "settings" -> Intent(Settings.ACTION_SETTINGS)
            "messages" -> resolveKnownOrGeneric("messages", Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_APP_MESSAGING)
            })
            "maps" -> resolveKnownOrGeneric("maps", Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0")))
            "youtube", "chrome", "whatsapp" -> resolveKnownPackageOnly(appKey)
            else -> null
        }

        intent?.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        return if (intent != null && intent.resolveActivity(context.packageManager) != null) {
            context.startActivity(intent)
            true
        } else {
            false
        }
    }

    private fun resolveKnownPackageOnly(appKey: String): Intent? {
        val pkg = knownPackages[appKey] ?: return null
        return if (isInstalled(pkg)) context.packageManager.getLaunchIntentForPackage(pkg) else null
    }

    private fun resolveKnownOrGeneric(appKey: String, generic: Intent): Intent {
        val pkg = knownPackages[appKey]
        if (pkg != null && isInstalled(pkg)) {
            context.packageManager.getLaunchIntentForPackage(pkg)?.let { return it }
        }
        return generic
    }
}

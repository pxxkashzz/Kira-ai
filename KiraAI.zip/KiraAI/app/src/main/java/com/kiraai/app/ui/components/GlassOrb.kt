package com.kiraai.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import com.kiraai.app.command.KiraState
import com.kiraai.app.ui.theme.KiraCyan
import com.kiraai.app.ui.theme.KiraViolet
import kotlin.math.cos
import kotlin.math.sin

/**
 * The central voice orb. Reacts to [state]:
 *  - Idle: slow "breathing" scale.
 *  - Listening: waveform ring driven by [amplitude] (0f..1f from the mic).
 *  - Processing: rotating light ring.
 *  - Speaking: pulsing glow.
 *
 * [reducedMotion] honors the Settings > Appearance > "Reduced-effects mode" /
 * system "reduce motion" preference: animations freeze at a neutral frame
 * instead of looping, per the accessibility and low-end-device requirements.
 */
@Composable
fun GlassOrb(
    state: KiraState,
    amplitude: Float,
    onTap: () -> Unit,
    modifier: Modifier = Modifier,
    reducedMotion: Boolean = false
) {
    val infinite = rememberInfiniteTransition(label = "orb")

    val breathing by if (reducedMotion) remember { mutableFloatStateOf(1f) } else infinite.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.04f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Reverse),
        label = "breathing"
    )

    val rotation by if (reducedMotion) remember { mutableFloatStateOf(0f) } else infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing)),
        label = "rotation"
    )

    val speakingPulse by if (reducedMotion) remember { mutableFloatStateOf(1f) } else infinite.animateFloat(
        initialValue = 0.9f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(500, easing = LinearEasing), RepeatMode.Reverse),
        label = "speakingPulse"
    )

    val baseScale = when (state) {
        KiraState.IDLE -> breathing
        KiraState.LISTENING -> 1f + (amplitude.coerceIn(0f, 1f) * 0.12f)
        KiraState.PROCESSING -> 1f
        KiraState.SPEAKING -> speakingPulse
    }

    val a11yLabel = when (state) {
        KiraState.IDLE -> "Kira microphone. Tap to speak."
        KiraState.LISTENING -> "Kira is listening."
        KiraState.PROCESSING -> "Kira is thinking."
        KiraState.SPEAKING -> "Kira is speaking."
    }

    Canvas(
        modifier = modifier
            .size(220.dp)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                onClick = onTap
            )
            .semantics { contentDescription = a11yLabel }
    ) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = (size.minDimension / 2f) * baseScale

        // Ambient outer glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(KiraCyan.copy(alpha = 0.20f), Color.Transparent),
                center = center,
                radius = radius * 1.9f
            ),
            radius = radius * 1.9f,
            center = center
        )

        // Glass sphere body
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color.White.copy(alpha = 0.22f),
                    KiraCyan.copy(alpha = 0.10f),
                    KiraViolet.copy(alpha = 0.06f)
                ),
                center = Offset(center.x - radius * 0.3f, center.y - radius * 0.3f),
                radius = radius * 1.6f
            ),
            radius = radius,
            center = center
        )

        // Thin glass rim
        drawCircle(
            color = Color.White.copy(alpha = 0.35f),
            radius = radius,
            center = center,
            style = Stroke(width = 1.5.dp.toPx())
        )

        // Specular highlight
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color.White.copy(alpha = 0.5f), Color.Transparent),
                center = Offset(center.x - radius * 0.35f, center.y - radius * 0.4f),
                radius = radius * 0.5f
            ),
            radius = radius * 0.45f,
            center = Offset(center.x - radius * 0.35f, center.y - radius * 0.4f)
        )

        when (state) {
            KiraState.LISTENING -> drawWaveformRing(center, radius, amplitude)
            KiraState.PROCESSING -> drawProcessingRing(center, radius, rotation)
            else -> Unit
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawWaveformRing(
    center: Offset,
    radius: Float,
    amplitude: Float
) {
    val bars = 28
    val level = amplitude.coerceIn(0.05f, 1f)
    for (i in 0 until bars) {
        val angle = (2 * Math.PI * i / bars)
        val barLen = radius * 0.18f * level * (0.4f + 0.6f * kotlin.random.Random(i).nextFloat())
        val inner = radius * 1.08f
        val outer = inner + barLen
        val start = Offset(
            center.x + (inner * cos(angle)).toFloat(),
            center.y + (inner * sin(angle)).toFloat()
        )
        val end = Offset(
            center.x + (outer * cos(angle)).toFloat(),
            center.y + (outer * sin(angle)).toFloat()
        )
        drawLine(
            color = KiraCyan.copy(alpha = 0.75f),
            start = start,
            end = end,
            strokeWidth = 3.dp.toPx(),
            cap = StrokeCap.Round
        )
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawProcessingRing(
    center: Offset,
    radius: Float,
    rotationDegrees: Float
) {
    rotate(rotationDegrees, pivot = center) {
        drawArc(
            brush = Brush.sweepGradient(
                colors = listOf(Color.Transparent, KiraViolet, KiraCyan, Color.Transparent),
                center = center
            ),
            startAngle = 0f,
            sweepAngle = 300f,
            useCenter = false,
            topLeft = Offset(center.x - radius * 1.08f, center.y - radius * 1.08f),
            size = androidx.compose.ui.geometry.Size(radius * 2.16f, radius * 2.16f),
            style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round)
        )
    }
}

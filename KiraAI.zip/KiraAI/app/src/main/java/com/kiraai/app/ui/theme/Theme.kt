package com.kiraai.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

private val KiraColorScheme = darkColorScheme(
    primary = KiraCyan,
    secondary = KiraViolet,
    background = KiraBackground,
    surface = GlassSurface,
    onPrimary = TextPrimary,
    onBackground = TextPrimary,
    onSurface = TextPrimary,
    error = KiraAmber
)

val KiraTypography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.Light, fontSize = 40.sp, letterSpacing = 1.sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.SemiBold, fontSize = 22.sp),
    titleMedium = TextStyle(fontWeight = FontWeight.Medium, fontSize = 17.sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.Normal, fontSize = 16.sp, color = TextPrimary),
    bodyMedium = TextStyle(fontWeight = FontWeight.Normal, fontSize = 14.sp, color = TextSecondary),
    labelSmall = TextStyle(fontWeight = FontWeight.Medium, fontSize = 12.sp, color = TextTertiary)
)

@Composable
fun KiraAITheme(content: @Composable () -> Unit) {
    // Kira is dark-glass by design regardless of system theme; isSystemInDarkTheme()
    // is kept here as a hook for a future "match system" appearance setting.
    isSystemInDarkTheme()
    MaterialTheme(
        colorScheme = KiraColorScheme,
        typography = KiraTypography,
        content = content
    )
}

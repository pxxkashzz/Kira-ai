package com.kiraai.app

import android.app.Application

class KiraApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        // Central place to wire up app-wide singletons if needed later.
    }
}

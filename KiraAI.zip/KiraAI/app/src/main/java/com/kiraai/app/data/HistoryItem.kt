package com.kiraai.app.data

data class HistoryItem(
    val id: Long,
    val command: String,
    val response: String,
    val timestampMillis: Long,
    val succeeded: Boolean
)

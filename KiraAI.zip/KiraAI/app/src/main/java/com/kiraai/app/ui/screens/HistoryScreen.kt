package com.kiraai.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kiraai.app.data.HistoryItem
import com.kiraai.app.ui.components.GlassCard
import com.kiraai.app.ui.theme.*
import com.kiraai.app.viewmodel.KiraViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun HistoryScreen(viewModel: KiraViewModel, onBack: () -> Unit) {
    var items by remember { mutableStateOf(viewModel.refreshHistory()) }

    Column(Modifier.fillMaxSize().background(KiraBackground)) {
        Row(
            Modifier.fillMaxWidth().padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    Icons.Filled.ArrowBack, "Back", tint = TextPrimary,
                    modifier = Modifier.clickable(onClick = onBack)
                )
                Spacer(Modifier.width(12.dp))
                Text("History", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
            }
            if (items.isNotEmpty()) {
                Text(
                    "Clear all",
                    color = KiraCyan,
                    fontSize = 14.sp,
                    modifier = Modifier.clickable {
                        viewModel.history.clear()
                        items = viewModel.refreshHistory()
                    }
                )
            }
        }

        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No commands yet", color = TextTertiary)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(items, key = { it.id }) { item ->
                    HistoryRow(item) {
                        viewModel.history.deleteItem(item.id)
                        items = viewModel.refreshHistory()
                    }
                }
            }
        }
    }
}

@Composable
private fun HistoryRow(item: HistoryItem, onDelete: () -> Unit) {
    val timeFormat = remember { SimpleDateFormat("hh:mm a", Locale.getDefault()) }
    GlassCard(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(item.command, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                Spacer(Modifier.height(4.dp))
                Text(timeFormat.format(Date(item.timestampMillis)), color = TextTertiary, fontSize = 12.sp)
                Spacer(Modifier.height(2.dp))
                Text(
                    if (item.succeeded) "Completed" else "Failed",
                    color = if (item.succeeded) KiraCyan else KiraAmber,
                    fontSize = 12.sp
                )
            }
            Icon(
                Icons.Filled.Delete, "Delete", tint = TextTertiary,
                modifier = Modifier.clickable(onClick = onDelete)
            )
        }
    }
}

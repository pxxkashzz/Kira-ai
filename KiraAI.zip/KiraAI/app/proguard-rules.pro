# Kira AI - keep speech/TTS related classes and app models from obfuscation issues
-keep class com.kiraai.app.data.** { *; }
-keep class com.kiraai.app.command.** { *; }
-dontwarn org.jetbrains.annotations.**
